Go to http://cohortgaming.com/aoc-forums

Read the installation instructions.  Watch the awesome gif.  

Email me if you have problems:
cohortgaming.com@gmail.com